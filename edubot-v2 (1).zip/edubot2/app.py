import os
import re
import requests
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

app = Flask(__name__, template_folder="templates")
CORS(app)

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
MURF_API_KEY = os.environ.get("MURF_API_KEY", "")
MODEL = "llama-3.3-70b-versatile"

# ── Emotion detection ──────────────────────────────────────────────────────────
EMOTION_KEYWORDS = {
    "sad":        ["sad", "depressed", "tired", "unhappy", "hopeless", "crying",
                   "upset", "miserable", "lonely", "fail", "failed", "can't do",
                   "giving up", "i give up", "too hard", "whatever", "don't care"],
    "frustrated": ["frustrated", "annoyed", "angry", "ugh", "stupid", "hate",
                   "nothing works", "impossible", "useless", "awful", "terrible",
                   "difficult", "hard", "can't", "stuck", "doesn't work"],
    "confused":   ["confused", "understand", "don't get", "what does", "what is",
                   "how does", "why does", "unclear", "lost", "help me", "explain",
                   "huh", "what", "how", "why", "not sure", "uncertain"],
    "excited":    ["excited", "amazing", "wow", "awesome", "love it", "fantastic",
                   "great", "cool", "interesting", "yes", "want to know",
                   "tell me more", "more about", "fascinating", "incredible"],
    "happy":      ["happy", "good", "thanks", "thank you", "nice", "got it",
                   "makes sense", "understand now", "clear now", "perfect", "great"],
    "curious":    ["curious", "wonder", "what if", "i wonder", "does that mean",
                   "so basically", "and then", "what about", "how about"],
    "bored":      ["boring", "bored", "skip", "already know", "move on", "next",
                   "not interested", "just tell me", "quickly"],
}

EMOTION_OPENERS = {
    "sad":        "Hey, don't worry — I'm right here with you. Let's work through this together 💙",
    "frustrated": "I totally get it, this can feel overwhelming. Take a breath — we'll crack it step by step 💪",
    "confused":   "No worries at all, confusion means you're thinking deeply! Let me make this crystal clear for you ✨",
    "excited":    "I love your excitement — let's ride that energy and go deep! 🚀",
    "happy":      "That positive energy is everything! Let's keep this momentum going 😊",
    "curious":    "Ooh, great question — your curiosity is the best thing you can bring to learning! 🧐",
    "bored":      "Alright, let me make this so interesting you won't be able to stop! ⚡",
    "neutral":    "",
}

def detect_emotion(text: str) -> str:
    lower = text.lower()
    scores = {}
    for em, kws in EMOTION_KEYWORDS.items():
        scores[em] = sum(1 for k in kws if k in lower)
    scores["neutral"] = 0.3
    return max(scores, key=scores.get)


# ── System prompt ──────────────────────────────────────────────────────────────
STYLE_MAP = {
    "sad":        "The student is sad or discouraged. Be very warm, gentle and encouraging. Start with empathy. Keep explanation simple, short and end with genuine encouragement.",
    "frustrated": "The student is frustrated. Acknowledge their struggle first. Be direct, clear and solution-focused. Skip unnecessary details. Give them a clear win quickly.",
    "confused":   "The student is confused. Use the simplest possible language. One concept at a time. Use a real-world analogy. Number your steps. Check understanding at the end.",
    "excited":    "The student is excited and highly engaged! Match their energy. Go deeper, add fascinating extra details, challenge them further, make it memorable.",
    "happy":      "The student is happy and receptive. Reinforce their understanding, build on it, add something surprising or delightful about the topic.",
    "curious":    "The student is curious. Feed that curiosity fully — rich explanations, surprising connections, invite further questions. Make them hungry for more.",
    "bored":      "The student is bored. Hook them immediately with the most surprising angle on this topic. Use vivid analogies, unexpected facts. Make this unforgettable.",
    "neutral":    "Provide a clear, helpful, well-structured educational response.",
}

def build_system_prompt(emotion: str, has_voice: bool) -> str:
    style = STYLE_MAP.get(emotion, STYLE_MAP["neutral"])
    opener = EMOTION_OPENERS.get(emotion, "")

    voice_note = ""
    if has_voice:
        voice_note = f"""
IMPORTANT - VOICE RESPONSE RULES:
- This will be spoken aloud. Write conversationally, NOT for reading.
- NO markdown symbols: no **, no *, no #, no bullet dashes, no numbered lists with dots.
- Use natural spoken transitions: "First...", "Then...", "And finally..."
- Short sentences. Natural pauses implied by periods.
- If the opener below applies, weave it naturally into your first sentence.
- Emotional opener to use: "{opener}"
"""
    else:
        voice_note = """
RESPONSE RULES:
- This is a text response. Use clear formatting with **bold** for key terms.
- You may use bullet points for lists.
- Be concise but complete.
"""

    return f"""You are an emotionally intelligent AI learning assistant for students.
You adapt your entire personality and teaching style to how the student feels.

STUDENT EMOTION: {emotion}
TEACHING STYLE: {style}
{voice_note}
ABSOLUTE RULES:
- Never mention any AI company names, model names, or technology providers.
- Never say you are "an AI" or "a language model". Just be a helpful tutor.
- End with exactly ONE follow-up question to check understanding or spark curiosity.
- Keep responses focused and under 200 words for voice, 300 for text."""


# ── Routes ─────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "voice": bool(MURF_API_KEY)})


@app.route("/api/chat", methods=["POST"])
def chat():
    if not GROQ_API_KEY:
        return jsonify({"error": "Service not configured. Please contact admin."}), 500

    body      = request.get_json(force=True)
    text      = body.get("text", "").strip()
    history   = body.get("history", [])
    has_voice = body.get("hasVoice", False)   # true = came from mic input

    if not text:
        return jsonify({"error": "No message received"}), 400

    # Only detect emotion when voice input is used
    emotion = detect_emotion(text) if has_voice else "neutral"

    messages = [{"role": "system", "content": build_system_prompt(emotion, has_voice)}]
    for turn in history[-6:]:
        if turn.get("role") in ("user", "assistant"):
            messages.append({"role": turn["role"], "content": turn["content"]})
    messages.append({"role": "user", "content": text})

    temp = {"excited": 0.9, "curious": 0.85, "confused": 0.5, "frustrated": 0.55}.get(emotion, 0.7)

    resp = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"},
        json={"model": MODEL, "messages": messages, "max_tokens": 500, "temperature": temp},
        timeout=30,
    )

    if not resp.ok:
        err = resp.json().get("error", {})
        return jsonify({"error": err.get("message", f"Error {resp.status_code}")}), 502

    reply = resp.json()["choices"][0]["message"]["content"]

    return jsonify({"reply": reply, "emotion": emotion})


@app.route("/api/tts", methods=["POST"])
def tts():
    if not MURF_API_KEY:
        return jsonify({"audioUrl": None, "fallback": True})

    body     = request.get_json(force=True)
    raw_text = body.get("text", "")
    gender   = body.get("gender", "female")   # "female" or "male"

    # Strip all markdown symbols for clean speech
    clean = re.sub(r"[*_#`>~\[\]()]", "", raw_text)
    clean = re.sub(r"\n+", " ", clean).strip()[:3000]

    # Fixed voices — medium speed, natural tone
    voice_map = {
        "female": "en-US-natalie",
        "male":   "en-US-marcus",
    }
    voice_id = voice_map.get(gender, "en-US-natalie")

    murf_resp = requests.post(
        "https://api.murf.ai/v1/speech/generate",
        headers={"api-key": MURF_API_KEY, "Content-Type": "application/json"},
        json={
            "voiceId": voice_id,
            "text": clean,
            "rate": 0,       # medium speed (0 = default, no fast/slow)
            "pitch": 0,
            "format": "MP3",
        },
        timeout=60,
    )

    if not murf_resp.ok:
        return jsonify({"audioUrl": None, "fallback": True})

    data = murf_resp.json()
    audio_url = data.get("audioFile") or data.get("encodedAudio") or None
    return jsonify({"audioUrl": audio_url, "fallback": not bool(audio_url)})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
